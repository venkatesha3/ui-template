export class TypeHeader{
    searchText:string;
    sugessions:string[];
    isTypeHeadResponseReceived=false;
    isTypeAHeadListMatched=false;
}