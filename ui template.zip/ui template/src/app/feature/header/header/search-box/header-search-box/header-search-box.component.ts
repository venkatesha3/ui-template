import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TypeHeader } from '../type-head.model';

@Component({
  selector: 'app-header-search-box',
  templateUrl: './header-search-box.component.html',
  styleUrls: ['./header-search-box.component.scss']
})
export class HeaderSearchBoxComponent implements OnInit {
  input:TypeHeader = new TypeHeader();
  searchText:string;
  constructor(private router:Router) { }
  
  ngOnInit(): void {
    this.input.searchText="";
  }
searchtext(){
this.router.navigate(["user-details"]);
}
onDownArrowPressed(){}

onUpArrowPressed(){}

textEnter(){}
onEscapePressed(){
  
}
}
