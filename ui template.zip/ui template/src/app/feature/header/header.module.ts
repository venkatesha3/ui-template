import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { HeaderContainerComponent } from './container/header-container/header-container.component';
import { HeaderSearchBoxComponent } from './header/search-box/header-search-box/header-search-box.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [HeaderComponent, HeaderContainerComponent, HeaderSearchBoxComponent],
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
  ],
  exports:[
    HeaderComponent
  ]
})
export class HeaderModule { }
