import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserDataComponent } from './core/components/user-data/user-data.component';
import { UserDetailsComponent } from './core/components/user-details/user-details.component';

const routes: Routes = [
  { path: '', redirectTo: 'user-details', pathMatch: "full" },
  { path: 'user-details', component: UserDetailsComponent },
  { path: 'user-data', component: UserDataComponent, data: { showBurgerMenu: true } },
  {
    path: 'home', loadChildren: () =>
      import("src/app/feature/home/home.module").then((m) => m.HomeModule),
    data: { preload: true, page: "Home", PageType: "home" }
  }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule {

}
