import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { UserDetailsComponent } from './core/components/user-details/user-details.component';
import {ReactiveFormsModule} from '@angular/forms';
import { UserDataComponent } from './core/components/user-data/user-data.component';
import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';
import { NavBarComponent } from './core/components/nav-bar/nav-bar.component';
import { AppServices } from './core/services/app-services';
import { SharedModule } from './shared/shared.module';
import { HeaderModule } from './feature/header/header.module';
import { FooterComponent } from './feature/footer/footer.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';


@NgModule({
 
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    TableModule,
    ButtonModule,
    SharedModule,
    HeaderModule,
    FontAwesomeModule
  ], declarations: [
    AppComponent,
    UserDetailsComponent,
    UserDataComponent,
    NavBarComponent,
    FooterComponent,
    
  ],
  providers: [AppServices],
  bootstrap: [AppComponent]
})
export class AppModule { }
