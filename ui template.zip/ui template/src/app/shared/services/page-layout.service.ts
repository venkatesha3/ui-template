import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { PageLayoutModel } from '../models/page-layout-model';

@Injectable({
  providedIn: 'root'
})
export class PageLayoutService {

  pageLayoutChanges$= new BehaviorSubject<PageLayoutModel>(new PageLayoutModel())
}
