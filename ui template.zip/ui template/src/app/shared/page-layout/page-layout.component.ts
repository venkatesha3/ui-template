import { state, trigger, style, transition, animate } from '@angular/animations';
import { Component, ElementRef, HostListener, OnInit, ViewChild } from '@angular/core';
import { NotificationService } from '../services/notification.service';
import { PageLayoutService } from '../services/page-layout.service';
//import {AppServices} from "app/core/services/app-services";
import { AppServices } from '../../core/services/app-services'
import { DeviceType } from 'src/app/core/enums/app-enum';
import { SkinnyHeaderService } from 'src/app/core/services/skinny-header-services';
import { HeaderState } from 'src/app/core/services/header-state-enum';
@Component({
  selector: 'app-page-layout',
  templateUrl: './page-layout.component.html',
  styleUrls: ['./page-layout.component.scss'],
  animations: [
    trigger("slideTopContainer", [
      state(
        "down",
        style({
          transform: "translatey(0%)",
        })
      ),
      state(
        "up",
        style({
          transform: "translatey(-100%)",
        })
      ),
      state(
        "init",
        style({
          transform: "translatey(0%)",
        })
      ),
      transition("down=>up", animate("250ms ease-in")),
      transition("up=>down", animate("250ms ease-out")),
    ])
  ]
})

export class PageLayoutComponent implements OnInit {
  @ViewChild('topContainer') topContainer: ElementRef;
  deviceType: DeviceType;
  _slideTopContainer: string = "";
  lastScrollTop = 0;
  pageLayout$: any;
  isNotificationVisible: boolean = true;
  skinnyHeaderOnclick: boolean;
  @HostListener("window:scroll", ["$event"])
  onWindowScroll(event) {
    let st = window.pageYOffset || document.documentElement.scrollTop;
    this.lastScrollTop = st;
    this.slideTopContainer(event)
  }
  constructor(
    private appServices: AppServices,
    private pageLayoutService: PageLayoutService,
    private notificationService: NotificationService,
    private skinnyHeaderService: SkinnyHeaderService,
  ) {
    this.deviceType = this.appServices.detectDeviceType();
    this.pageLayout$ = pageLayoutService;
    this.notificationService.onVisibilityChange$.subscribe((isVisible) => {
      this.isNotificationVisible = isVisible;
    })
  }

  ngOnInit(): void {
    this.skinnyHeaderService.headerState.subscribe((headerState) => {
      if (headerState.state == HeaderState.up) {
        this._slideTopContainer = "up";
        this.appServices.setHeaderHeight(0)
      } else {
        headerState.state == HeaderState.init
          ? (this._slideTopContainer = "init")
          : (this._slideTopContainer = "down");
        this.appServices.setHeaderHeight(
          this.topContainer.nativeElement.offsetHeight
        )
      }
    }
    )
  }
  slideTopContainer(event) {
    if (this.lastScrollTop > this.topContainer.nativeElement.offsetHeight) {
      this.skinnyHeaderService.slideHeader(HeaderState.up, event)
    } else {
      this.skinnyHeaderService.slideHeader(HeaderState.down, event)
    }
  }
}
