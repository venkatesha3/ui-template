import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContextualBarComponent } from './contextual-bar.component';

describe('ContextualBarComponent', () => {
  let component: ContextualBarComponent;
  let fixture: ComponentFixture<ContextualBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContextualBarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContextualBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
