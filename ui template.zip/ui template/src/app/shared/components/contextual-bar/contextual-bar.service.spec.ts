import { TestBed } from '@angular/core/testing';

import { ContextualBarService } from './contextual-bar.service';

describe('ContextualBarService', () => {
  let service: ContextualBarService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ContextualBarService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
