import { trigger, state, style, transition, animate } from '@angular/animations';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { HeaderState } from 'src/app/core/services/header-state-enum';
import { SkinnyHeaderService } from 'src/app/core/services/skinny-header-services';
import { ContextualBarService } from './contextual-bar.service';

import { faChevronLeft, faChevronRight } from '@fortawesome/free-solid-svg-icons';
import { RouteStatus } from 'src/app/core/services/navigation/route.status';
import { NavigationService } from 'src/app/core/services/navigation/navigation.service';
@Component({
  selector: 'app-contextual-bar',
  templateUrl: './contextual-bar.component.html',
  styleUrls: ['./contextual-bar.component.scss'],
  animations: [
    trigger("slideContextualBar", [
      state(
        "down",
        style({})
      ),
      state(
        "up",
        style({
          position: "fixed",
          top: 0,
          right: 0,
          width: "100%"
        })
      ),
      transition("down=>up", animate("250ms ease-in")),
      transition("up=>down", animate("250ms ease-out"))
    ])
  ],
  host: {
    "(document:click)": "OnClick($event)",
    "(mouseenter)": "cnbMouseEnter($event)"
  },
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ContextualBarComponent implements OnInit,OnDestroy {
  faChevronLeft = faChevronLeft;
  faChevronRight = faChevronRight;
  slideContextualBar: string = "";
  routestatus: RouteStatus;
  navigationSubscription:any;
  constructor(private skinnyHeaderService: SkinnyHeaderService,
    private cdRef: ChangeDetectorRef,
    private contextualBarService: ContextualBarService,
    private navigationService: NavigationService) {
    this.skinnyHeaderService.headerState.subscribe((headerstate) => {
      this.slideContextualBar = headerstate.state == HeaderState.up ? "up" : "down";
      this.cdRef.markForCheck()
    })
  }
  cnbMouseEnter($event) {

  }
  OnClick($event) {

  }
  ngOnInit(): void {
    this.routestatus = new RouteStatus();
    this.navigationSubscription = this.navigationService.routeStatus$.subscribe((routeStatus)=>[
      this.routestatus=routeStatus
    ]);
    this.navigationService.getActivateRoute();
  }
  navigateBack() {
    this.navigationService.navigationBack();
  }
  navigateForward() {
    this.navigationService.navigateForward();
  }
  ngOnDestroy(){
    this.navigationSubscription.unsubscribe();
  }
}
