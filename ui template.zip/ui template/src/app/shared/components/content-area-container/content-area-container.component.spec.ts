import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContentAreaContainerComponent } from './content-area-container.component';

describe('ContentAreaContainerComponent', () => {
  let component: ContentAreaContainerComponent;
  let fixture: ComponentFixture<ContentAreaContainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContentAreaContainerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContentAreaContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
