import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-area-container',
  templateUrl: './content-area-container.component.html',
  styleUrls: ['./content-area-container.component.scss']
})
export class ContentAreaContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
