import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificationComponent } from './notification/notification.component';
import { PageLayoutComponent } from './page-layout/page-layout.component';
import { ContentAreaContainerComponent } from './components/content-area-container/content-area-container.component';
import { ContextualBarComponent } from './components/contextual-bar/contextual-bar.component';

import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { SvgIconComponent } from './components/svg-icon/svg-icon.component';


@NgModule({
  declarations: [NotificationComponent,
    PageLayoutComponent,
    ContentAreaContainerComponent,
    ContextualBarComponent,
    SvgIconComponent],
  imports: [
    CommonModule,
    FontAwesomeModule
  ],
  exports: [NotificationComponent,SvgIconComponent,
    PageLayoutComponent,
    ContentAreaContainerComponent,
    ContextualBarComponent, CommonModule]
})
export class SharedModule { }
