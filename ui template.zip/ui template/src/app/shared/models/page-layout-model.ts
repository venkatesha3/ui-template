export class PageLayoutModel{
    isHeaderVisible:boolean=true;
    isBodyVisible:boolean=true;
    isFooterVisible:boolean=true;
}