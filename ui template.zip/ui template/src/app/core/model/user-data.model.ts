export class UserDataModel {
    constructor(
        userName = "",
        email = "",
        phoneNumber = "",
        boardType = "",
        qualification = [],
    ) {
        this.userName = userName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.qualification = qualification;
        this.boardType = boardType;
    }
    userName: string;
    email: string;
    phoneNumber: string;
    boardType: string;
    qualification: Array<string>;
}
