import { PreloadingStrategy, Route, Router } from "@angular/router";
import { Observable, of } from "rxjs";

export class preLoadingStategy implements PreloadingStrategy{
    constructor(){

    }
    preload(route:Route,load:()=>Observable<any>):Observable<any>{
        return route.data && route.data.preload?load():of(null);
    }
}