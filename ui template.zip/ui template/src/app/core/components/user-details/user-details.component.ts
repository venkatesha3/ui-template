import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray, FormBuilder, RequiredValidator } from '@angular/forms';
import { UserDetailsService } from '../../services/user-details.service';
import { UserDataModel } from '../../model/user-data.model';
import { Router } from '@angular/router';
import { FilterDataService } from '../../services/filter-data.service';
@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.scss']
})
export class UserDetailsComponent implements OnInit {
  SignupForm: FormGroup;
  qualifications = ["Graduation", "Post Graduation", "Primary Education"];
  submitted = false;
  constructor(private formBuilder: FormBuilder,
    private userDetailsService: UserDetailsService,
    private router: Router, 
    private filterDataService:FilterDataService) { 
      this.filterDataService.viewBurgermenu$.next(false);
    }
  value4: string;
  qualification: FormArray;
  ngOnInit(): void {
    this.SignupForm = new FormGroup({
      'userName': new FormControl(null, [Validators.required]),
      'email': new FormControl(null, [Validators.required, Validators.email]),
      'phoneNumber': new FormControl(null, [Validators.required, Validators.minLength(10), Validators.maxLength(10)]),
      'boardType': new FormControl(null, [Validators.required]),
      'qualification': new FormArray(this.qualifications.map(item => this.createItem(item))),
    });
  }

  get f() { return this.SignupForm.controls; }
  createItem(qulifaction): FormControl {
    return this.formBuilder.control(qulifaction)
  }
  navigateUserDetails() {
    this.router.navigate(["user-data"]);
  }
  onSubmit() {
    this.submitted = true;
    if (this.SignupForm.invalid) {
      return;
    }
    console.log(this.SignupForm);
    const slctdQualifications = new Array<string>()
    this.SignupForm.value.qualification.map((item, i) => {
      if (item) slctdQualifications.push(this.qualifications[i])
    })
    const userData = this.SignupForm.value as UserDataModel;
    userData.qualification = [...slctdQualifications];
    this.userDetailsService.setUserData(userData);
    this.router.navigate(["user-data"]);
  }
}

