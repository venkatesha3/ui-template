export class FilterparamsModel{
    boardType:string;
    qualification:[string] ;
}