export class RouteStatus{
    routeUrl:string;
    canGoBack:boolean;
    canGoForward:boolean;
}