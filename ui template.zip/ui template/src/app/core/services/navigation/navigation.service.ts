import { Injectable } from '@angular/core';
import { ActivatedRoute, NavigationEnd, NavigationStart, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { AppRouteModel } from './app-route.model';
import { RouteStatus } from './route.status';
import { filter } from 'rxjs/operators';
import { ReturnStatement } from '@angular/compiler';
@Injectable({
  providedIn: 'root'
})
export class NavigationService {
  private routeCollection: Array<AppRouteModel>;
  routeStatus$: Subject<RouteStatus>;
  ignorerouteEvent: boolean;
  isRedirect: boolean;
  routestatus: RouteStatus;
  store: Storage;
  ROUTE_STATE_KEY = new Date().valueOf().toString();
  private navigationCount = 0;
  private navigationId = 0;

  private _cancelCurrentRoute: boolean;
  constructor(private router: Router, activatedRoute: ActivatedRoute) {
    this.routeCollection = new Array<AppRouteModel>();
    this.routeStatus$ = new Subject<RouteStatus>();
    this.routestatus = new RouteStatus();
    this.ignorerouteEvent = false;
    this.store = window.sessionStorage || window.localStorage;
    this.router.events.pipe(filter((event) => event instanceof NavigationStart)).subscribe((navigationEvent) => {
      this.navigationId = (<any>navigationEvent).id;
      this._cancelCurrentRoute = true;

    })
    this.router.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe((navigationEvent) => {
      // this.navigationId=(<any>navigationEvent).id;
      // this._cancelCurrentRoute = true;
      if (this.isRedirect) {
        this.navigationCount++;
      }
      this.isRedirect = false;
      if (this.ignorerouteEvent) {
        this.ignorerouteEvent = false
      } else {
        let lastActiveIndex = this.routeCollection.findIndex((route) => route.active);
        const spliceLength = lastActiveIndex >= 0
          ? this.routeCollection.length - lastActiveIndex
          : 0;
        this.routeCollection = this.routeCollection.map((appRoute) => Object.assign(appRoute, { active: false }));
        this.routeCollection.splice(
          lastActiveIndex + 1,
          spliceLength,
          new AppRouteModel(this.router.url, true)
        )
      }
      this.routestatus.routeUrl = this.router.url;
      this.routestatus.canGoBack = this.routeCollection.length && !this.routeCollection[0].active;
      this.routestatus.canGoForward = this.routeCollection.length > 1 && this.routeCollection[this.routeCollection.length - 1].active;
      this.routeStatus$.next(this.routestatus)
    })
  }
cancelCurentRoute(){
  this._cancelCurrentRoute= true;
}
navigationBack(){
  const activeRouteIndex= this.routeCollection.findIndex(item=>item.active==true);
  if(activeRouteIndex-1<0) return;
  this.routeCollection = this.routeCollection.map((appRoute) => Object.assign(appRoute, { active: false }));
  this.routeCollection[activeRouteIndex-1].active = true;
  this.router.navigateByUrl(this.routeCollection[activeRouteIndex-1].url)
  this.ignorerouteEvent= true;
}
getActivateRoute(){
  this.routeStatus$.next(this.routestatus);
  return this.routestatus

}
navigateForward(){
  const activeRouteIndex= this.routeCollection.findIndex(item=>item.active==true);
  if(activeRouteIndex+1==this.routeCollection.length) return;
  this.routeCollection = this.routeCollection.map((appRoute) => Object.assign(appRoute, { active: false }));
  this.routeCollection[activeRouteIndex+1].active = true;
  this.router.navigateByUrl(this.routeCollection[activeRouteIndex+1].url)
  this.ignorerouteEvent= true;
}
exportRouteState():string{
this.store.setItem(
  this.ROUTE_STATE_KEY,
  JSON.stringify(this.routeCollection))
  return this.ROUTE_STATE_KEY;
}
importRouteState(routeStateKey=this.ROUTE_STATE_KEY){
  this.routeCollection.unshift(
...JSON.parse(this.store.getItem(this.ROUTE_STATE_KEY))
  );

}
resetRouteCollection(){
  this.routeCollection =  Array<AppRouteModel>();
  this.routestatus = new RouteStatus()
  this.routeStatus$.next(this.routestatus)
}
isFirstNavigation(){
  return !this.navigationCount
}
getnavigationId(){
  return this.navigationId;
}
}
