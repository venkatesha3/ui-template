export class AppRouteModel{
    url:string;
    active:boolean;
    constructor(url:string,active:boolean ){
        this.url=url
        this.active=active;
    }
}