import { HeaderState } from "./header-state-enum";

export class SkinnyHeaderStateModel{
    state:HeaderState;
    _event:Event;
}