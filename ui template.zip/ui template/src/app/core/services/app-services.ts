import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { DeviceType } from "../enums/app-enum";

@Injectable({
    providedIn: 'root'
  })
export class AppServices{
    appheaderHeight$:BehaviorSubject<number>;
    constructor(){
        this.appheaderHeight$= new BehaviorSubject<number>(0);
    }
    setHeaderHeight(height){
        this.appheaderHeight$.next(height)
    }
    detectDeviceType(){
        return DeviceType.Desktop;
    }
}