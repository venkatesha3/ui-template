import { Injectable } from "@angular/core";
import { Subject } from "rxjs";
import { DeviceType } from "../enums/app-enum";
import { AppServices } from "./app-services";
import { HeaderState } from "./header-state-enum";
import { SkinnyHeaderStateModel } from "./skinny-header-model";

@Injectable({
    providedIn: 'root'
})
export class SkinnyHeaderService {
    headerState: Subject<SkinnyHeaderStateModel>;
    currentHeaderState: HeaderState;
    private deviceType: DeviceType;
    constructor(private appService: AppServices) {
    this.headerState= new Subject<SkinnyHeaderStateModel>();
    }
    slideHeader(headerState: HeaderState, _event: Event = null) {
        this.currentHeaderState = headerState;
        if (this.deviceType == DeviceType.Desktop) {
            let skinnyHeaserModel = new SkinnyHeaderStateModel();
            skinnyHeaserModel.state = headerState;
            skinnyHeaserModel._event = _event;
            this.headerState.next(skinnyHeaserModel);
        }
    }
}