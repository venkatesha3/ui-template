export enum HeaderState{
    up,
    down,
    init
}