export enum DeviceType{
    Mobile,
    Desktop,
    Tablet
}
export enum Status{
    Success,
    Failure,
    Warning
}